"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./src/components/Main/index.tsx":
/*!***************************************!*\
  !*** ./src/components/Main/index.tsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles */ \"./src/components/Main/styles.ts\");\n\n\nconst Main = ({ title =\"React Avan\\xe7ado\" , description =\"TypeScript, ReactJS, NextJS e Styled Components\"  })=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_1__.Wrapper, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_1__.Logo, {\n                src: \"/img/logo.svg\",\n                alt: \"Imagem de um \\xe1tomo e React Avan\\xe7ado escrito ao lado.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\teste\\\\strapiudemy\\\\Nova pasta\\\\boilerplate_nextjs\\\\src\\\\components\\\\Main\\\\index.tsx\",\n                lineNumber: 7,\n                columnNumber: 5\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_1__.Title, {\n                children: title\n            }, void 0, false, {\n                fileName: \"C:\\\\teste\\\\strapiudemy\\\\Nova pasta\\\\boilerplate_nextjs\\\\src\\\\components\\\\Main\\\\index.tsx\",\n                lineNumber: 11,\n                columnNumber: 5\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_1__.Description, {\n                children: description\n            }, void 0, false, {\n                fileName: \"C:\\\\teste\\\\strapiudemy\\\\Nova pasta\\\\boilerplate_nextjs\\\\src\\\\components\\\\Main\\\\index.tsx\",\n                lineNumber: 12,\n                columnNumber: 5\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_styles__WEBPACK_IMPORTED_MODULE_1__.Illustration, {\n                src: \"/img/hero-illustration.svg\",\n                alt: \"Um desenvolvedor de frente para uma tela com c\\xf3digo.\"\n            }, void 0, false, {\n                fileName: \"C:\\\\teste\\\\strapiudemy\\\\Nova pasta\\\\boilerplate_nextjs\\\\src\\\\components\\\\Main\\\\index.tsx\",\n                lineNumber: 13,\n                columnNumber: 5\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\teste\\\\strapiudemy\\\\Nova pasta\\\\boilerplate_nextjs\\\\src\\\\components\\\\Main\\\\index.tsx\",\n        lineNumber: 6,\n        columnNumber: 3\n    }, undefined);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Main);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9NYWluL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFBNkI7QUFDN0IsTUFBTUMsSUFBSSxHQUFHLENBQUMsRUFDWkMsS0FBSyxFQUFHLG1CQUFnQixHQUN4QkMsV0FBVyxFQUFHLGlEQUFpRCxHQUNoRSxpQkFDQyw4REFBQ0gsNENBQVM7OzBCQUNSLDhEQUFDQSx5Q0FBTTtnQkFDTE0sR0FBRyxFQUFDLGVBQWU7Z0JBQ25CQyxHQUFHLEVBQUMsNERBQXNEOzs7Ozt5QkFDMUQ7MEJBQ0YsOERBQUNQLDBDQUFPOzBCQUFFRSxLQUFLOzs7Ozt5QkFBVzswQkFDMUIsOERBQUNGLGdEQUFhOzBCQUFFRyxXQUFXOzs7Ozt5QkFBaUI7MEJBQzVDLDhEQUFDSCxpREFBYztnQkFDYk0sR0FBRyxFQUFDLDRCQUE0QjtnQkFDaENDLEdBQUcsRUFBQyx5REFBc0Q7Ozs7O3lCQUMxRDs7Ozs7O2lCQUNRO0FBR2QsaUVBQWVOLElBQUkiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9yZWFjdC1hdmFuY2Fkby1ib2lsZXJwbGF0ZS8uL3NyYy9jb21wb25lbnRzL01haW4vaW5kZXgudHN4PzhkZDYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUyBmcm9tICcuL3N0eWxlcydcclxuY29uc3QgTWFpbiA9ICh7XHJcbiAgdGl0bGUgPSAnUmVhY3QgQXZhbsOnYWRvJyxcclxuICBkZXNjcmlwdGlvbiA9ICdUeXBlU2NyaXB0LCBSZWFjdEpTLCBOZXh0SlMgZSBTdHlsZWQgQ29tcG9uZW50cydcclxufSkgPT4gKFxyXG4gIDxTLldyYXBwZXI+XHJcbiAgICA8Uy5Mb2dvXHJcbiAgICAgIHNyYz1cIi9pbWcvbG9nby5zdmdcIlxyXG4gICAgICBhbHQ9XCJJbWFnZW0gZGUgdW0gw6F0b21vIGUgUmVhY3QgQXZhbsOnYWRvIGVzY3JpdG8gYW8gbGFkby5cIlxyXG4gICAgLz5cclxuICAgIDxTLlRpdGxlPnt0aXRsZX08L1MuVGl0bGU+XHJcbiAgICA8Uy5EZXNjcmlwdGlvbj57ZGVzY3JpcHRpb259PC9TLkRlc2NyaXB0aW9uPlxyXG4gICAgPFMuSWxsdXN0cmF0aW9uXHJcbiAgICAgIHNyYz1cIi9pbWcvaGVyby1pbGx1c3RyYXRpb24uc3ZnXCJcclxuICAgICAgYWx0PVwiVW0gZGVzZW52b2x2ZWRvciBkZSBmcmVudGUgcGFyYSB1bWEgdGVsYSBjb20gY8OzZGlnby5cIlxyXG4gICAgLz5cclxuICA8L1MuV3JhcHBlcj5cclxuKVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWFpblxyXG4iXSwibmFtZXMiOlsiUyIsIk1haW4iLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiV3JhcHBlciIsIkxvZ28iLCJzcmMiLCJhbHQiLCJUaXRsZSIsIkRlc2NyaXB0aW9uIiwiSWxsdXN0cmF0aW9uIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/Main/index.tsx\n");

/***/ }),

/***/ "./src/components/Main/styles.ts":
/*!***************************************!*\
  !*** ./src/components/Main/styles.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"Description\": () => (/* binding */ Description),\n/* harmony export */   \"Illustration\": () => (/* binding */ Illustration),\n/* harmony export */   \"Logo\": () => (/* binding */ Logo),\n/* harmony export */   \"Title\": () => (/* binding */ Title),\n/* harmony export */   \"Wrapper\": () => (/* binding */ Wrapper)\n/* harmony export */ });\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);\n\nconst Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default().main.withConfig({\n    displayName: \"styles__Wrapper\",\n    componentId: \"sc-4888d1be-0\"\n})`\r\n  background-color: #06092b;\r\n  color: #fff;\r\n  width: 100%;\r\n  height: 100%;\r\n  padding: 3rem;\r\n  text-align: center;\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  justify-content: center;\r\n`;\nconst Logo = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({\n    displayName: \"styles__Logo\",\n    componentId: \"sc-4888d1be-1\"\n})`\r\n  width: 25rem;\r\n  margin-bottom: 2rem;\r\n`;\nconst Title = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h1.withConfig({\n    displayName: \"styles__Title\",\n    componentId: \"sc-4888d1be-2\"\n})`\r\n  font-size: 2.5rem;\r\n`;\nconst Description = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2.withConfig({\n    displayName: \"styles__Description\",\n    componentId: \"sc-4888d1be-3\"\n})`\r\n  font-size: 2rem;\r\n  font-weight: 400;\r\n`;\nconst Illustration = styled_components__WEBPACK_IMPORTED_MODULE_0___default().img.withConfig({\n    displayName: \"styles__Illustration\",\n    componentId: \"sc-4888d1be-4\"\n})`\r\n  margin-top: 3rem;\r\n  width: min(30rem, 100%);\r\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9NYWluL3N0eWxlcy50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQXNDO0FBRS9CLE1BQU1DLE9BQU8sR0FBR0Qsd0VBQVc7OztFQUFBLENBQUM7QUFhbkMsT0FBTyxNQUFNRyxJQUFJLEdBQUdILE1BQU0sQ0FBQ0k7OztFQUFHLENBQUM7QUFLL0IsT0FBTyxNQUFNQzs7O0VBQWlCLENBQUM7QUFJL0IsT0FBTyxNQUFNRTs7O0FBQXdCO0FBS3JDLE9BQU8sTUFBTUUsWUFBWSxHQUFHVDs7O0VBQVUsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3JlYWN0LWF2YW5jYWRvLWJvaWxlcnBsYXRlLy4vc3JjL2NvbXBvbmVudHMvTWFpbi9zdHlsZXMudHM/ZmM0OSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gJ3N0eWxlZC1jb21wb25lbnRzJ1xyXG5cclxuZXhwb3J0IGNvbnN0IFdyYXBwZXIgPSBzdHlsZWQubWFpbmBcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDYwOTJiO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBwYWRkaW5nOiAzcmVtO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuYFxyXG5cclxuZXhwb3J0IGNvbnN0IExvZ28gPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiAyNXJlbTtcclxuICBtYXJnaW4tYm90dG9tOiAycmVtO1xyXG5gXHJcblxyXG5leHBvcnQgY29uc3QgVGl0bGUgPSBzdHlsZWQuaDFgXHJcbiAgZm9udC1zaXplOiAyLjVyZW07XHJcbmBcclxuXHJcbmV4cG9ydCBjb25zdCBEZXNjcmlwdGlvbiA9IHN0eWxlZC5oMmBcclxuICBmb250LXNpemU6IDJyZW07XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuYFxyXG5cclxuZXhwb3J0IGNvbnN0IElsbHVzdHJhdGlvbiA9IHN0eWxlZC5pbWdgXHJcbiAgbWFyZ2luLXRvcDogM3JlbTtcclxuICB3aWR0aDogbWluKDMwcmVtLCAxMDAlKTtcclxuYFxyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsIm1haW4iLCJMb2dvIiwiaW1nIiwiVGl0bGUiLCJoMSIsIkRlc2NyaXB0aW9uIiwiaDIiLCJJbGx1c3RyYXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/Main/styles.ts\n");

/***/ }),

/***/ "./src/pages/index.tsx":
/*!*****************************!*\
  !*** ./src/pages/index.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Home)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var components_Main__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! components/Main */ \"./src/components/Main/index.tsx\");\n\n\nfunction Home() {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(components_Main__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n        fileName: \"C:\\\\teste\\\\strapiudemy\\\\Nova pasta\\\\boilerplate_nextjs\\\\src\\\\pages\\\\index.tsx\",\n        lineNumber: 3,\n        columnNumber: 10\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFBQTtBQUFrQztBQUNuQixTQUFTQyxJQUFJLEdBQUc7SUFDN0IscUJBQU8sOERBQUNELHVEQUFJOzs7O1lBQUc7QUFDakIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3JlYWN0LWF2YW5jYWRvLWJvaWxlcnBsYXRlLy4vc3JjL3BhZ2VzL2luZGV4LnRzeD8xOWEwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBNYWluIGZyb20gJ2NvbXBvbmVudHMvTWFpbidcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcclxuICByZXR1cm4gPE1haW4gLz5cclxufVxyXG4iXSwibmFtZXMiOlsiTWFpbiIsIkhvbWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/index.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/index.tsx"));
module.exports = __webpack_exports__;

})();